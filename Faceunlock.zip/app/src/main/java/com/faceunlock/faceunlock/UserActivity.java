package com.faceunlock.faceunlock;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

public class UserActivity extends AppCompatActivity {
    Button btnAdduser,btnRemUser,btnUserl,btnHelp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        btnAdduser=(Button)findViewById(R.id.btnAddUser);
        btnRemUser=(Button)findViewById(R.id.btnRemoveUser);
        btnUserl=(Button)findViewById(R.id.btnUserlog);
        btnHelp=(Button)findViewById(R.id.btnHelp);
    }
}
